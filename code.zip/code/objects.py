import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
from config import BG_THRESHOLDS
from config import REWARD_ARR
from config import SCORE_ARR
from config import ACTION_SPACE_ARR
from config import TIR_THRESHOLDS
from config import STATE_LENGTH
from config import N_PAST_INSULIN_INJECTIONS
from config import N_PAST_BG_VALUES
from functools import cache


# @cache
def Table(BG:float):
    """
    BG value to state number table.
    
    BG = BG values or CGM values (float)
    
    This function sort continuos BG values into discrete bins, and returns
    the bins state number - 1. ie. returns a integer in the range [0,1] 
    based on the given input.
    """
    thresholds = BG_THRESHOLDS
    state_index = np.searchsorted(thresholds, BG, side='right')
    return state_index


def reward_fun(BG, done, actual_BG):
    """Returns the reward based on Table and reward_arr"""
    if done:
        print("done =", done, BG[-1], actual_BG)
        return -1000
    else:
        BG = np.array(BG).astype(np.int64)
        return np.mean(REWARD_ARR[Table(BG)])            # uses int to save computation time.




class make_BGAgent():
    def __init__(
        self,
        learning_rate:float,
        initial_epsilon:float,
        epsilon_decay:float,
        final_epsilon:float,
        discount_factor:float=0.95,
        initial_Q=np.array({}),
        initial_N=np.array({})):
        """
        Initialize the training Agent with a learning rate, epsilon,
        and an empty dictionary of Q-values of state-action pairs.
        
        learning_rate   = The learning rate of the model
        initial_epsilon = The initial value of epsilon before the decay is 
        epsilon_decay   = The decay factor for epsilon during training
        final_epsilon   = The final value for epsilon. epsilon will not decay further than this value.
        discount_factor = The discount factor of the model
        initial_Q       = A dictionary with initial Q values
        initial_N       = A dictionary with initial N values
        
        Further explanations of the method and the output.
        """
        self.action_space = np.arange(len(ACTION_SPACE_ARR))
        self.Q = defaultdict(lambda:np.zeros_like(self.action_space).astype(np.float64))
        self.N = defaultdict(lambda:np.zeros_like(self.action_space).astype(np.int64))
        if len(initial_Q.item()) > 0:
            print("Initializing Q")
            self.Q.update(initial_Q.item())
        if len(initial_N.item()) > 0:
            print("Initializing N")
            self.N.update(initial_N.item())
        
        self.epsilon = initial_epsilon
        self.epsilon_decay = epsilon_decay
        self.final_epsilon = final_epsilon
        
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        
        self.training_error = []

    def policy(self, obs, c=0):
        """
        Implementation of the epsilon-greedy policy with an upper confidence bound selection.
        
        obs = Currant state
        
        This method takes the currant state and returns the next best (greedy) action
        with probability 1-epsilon and an random next action with probability epsilon
        """
        if np.random.uniform() < self.epsilon:
            action = np.random.choice(self.action_space)
        else:
            action = np.argmax(self.Q[obs] + c * np.sqrt(np.log(np.sum(self.N[obs]) + 1)/(self.N[obs] + 1e-5)))
        return action, ACTION_SPACE_ARR[action]
    
    def pi(self, obs):
        """pi for epsilon-greedy policy"""
        pi_arr = np.zeros(self.action_space.shape)
        pi_arr[:] = self.epsilon/len(self.action_space)
        pi_arr[np.argmax(self.Q[obs])] = (1-self.epsilon)
        return pi_arr
    
    def update(self, obs, action, reward, terminated, next_obs):
        """
        Updates the Q-values.
        
        obs         = The agents currant state
        action      = The chosen action in discrete form ie. [1,2,3,4]
        reward      = The reward of following the chosen action at our currant state
        terminated  = True if the agent has reached the terminal state otherwise False
        next_obs    = The agents next state after following the chosen action.
        
        This method calculates the the Temporal difference (TD) and updates the Q-values
        trough the of-policy Q-learning algorithm. 
        """
        self.N[obs][action] += 1
        # Q-learning:
        future_Q = (not terminated) * np.max(self.Q[next_obs])
        
        """
        # # Sarsa:
        # future_Q = (not terminated) * self.Q[next_obs][self.policy(next_obs)]
        
        # # Expected Sarsa:
        # future_Q = (not terminated) * np.sum(self.Q[next_obs]*self.pi[next_obs])
        
        # # Double Q-learning:      (Need to define Q1 and Q2 and change the policy to sum or average of Q1, Q2)
        # if np.random.uniform > 0.5:
        #     future_Q = (not terminated) * self.Q2[next_obs, np.argmax(self.Q1[next_obs])]
        #     TD = reward + self.discount_factor * future_Q - self.Q1[obs][action]
        #     self.Q1 += self.learning_rate * TD
        # else:
        #     future_Q = (not terminated) * self.Q1[next_obs, np.argmax(self.Q2[next_obs])]
        #     TD = reward + self.discount_factor * future_Q - self.Q2[obs][action]
        #     self.Q2 += self.learning_rate * TD
        """
        TD = reward + self.discount_factor * future_Q - self.Q[obs][action]
        
        self.Q[obs][action] += self.learning_rate * TD
        self.training_error.append(TD)
    
    def update_epsilon(self):
        """Decreases epsilon according to the given epsilon parameters"""
        self.epsilon = np.max((self.final_epsilon, self.epsilon - self.epsilon_decay))

    def n_step_TD(self, obs, action, reward, terminated, next_obs):
        """ RL book page 144 """
        pass


class State():
    def __init__(self):
        """An object to store and update the state during training"""
        self.S = np.zeros(STATE_LENGTH + 1)
        self.reset()
    
    def reset(self):
        """Resets the state vector to nan values"""
        self.S[:] = np.nan
    
    def update(self, obs, t):
        """
        Update the stat vector based on the currant observation and time
        
        obs = raw BG value
        t = time step
        """
        obs = Table(obs[0])
        self.S[:-2] = self.S[1:-1]
        self.S[-2:] = obs, t
        return str(self.S.copy())


class new_State():
    def __init__(self):
        """An object to store and update the state during training"""
        self.S = np.zeros(N_PAST_BG_VALUES)
        self.I = np.zeros(N_PAST_INSULIN_INJECTIONS)
        self.new_state = np.zeros(N_PAST_INSULIN_INJECTIONS + N_PAST_BG_VALUES + 1)
        self.reset()
    
    def reset(self):
        """Resets the state vector to nan values"""
        self.S[:] = np.nan
        self.I[:] = 0
    
    def update(self, obs, action, t):
        """
        Update the stat vector based on the currant observation and time
        
        obs = raw BG value
        t = time step
        """
        obs = Table(obs[0])
        self.S[:-1] = self.S[1:]
        self.S[-1] = obs
        
        self.I[:-1] = self.I[1:]
        self.I[-1] = action
        
        
        self.new_state[:N_PAST_INSULIN_INJECTIONS] = self.I
        self.new_state[N_PAST_INSULIN_INJECTIONS:-1] = self.S
        self.new_state[-1] = t
        
        return str(self.new_state.copy())


class TIR():
    def __init__(self):
        """An object to store and update the TIR score during simulation"""
        self.reset()
    
    def reset(self):
        """Reset the in range count to 0"""
        self.IR = 0
    
    def update(self, obs):
        """
        Update the in range count.
        
        obs = CGM reading in array form, ie. [CGM]
        """
        if TIR_THRESHOLDS[0] <= obs[0] <= TIR_THRESHOLDS[1]:
            self.IR +=1
    
    def __call__(self, n):
        """returns the TIR currant score"""
        return self.IR/n


class Score():
    def __init__(self):
        """An object to store and update the Score"""
        self.reset()
    
    def reset(self):
        """Reset the total score to 0"""
        self.total_score = 0
    
    def update(self, obs):
        """
        Update the running sum of score values
        
        obs = obs = CGM reading in array form, ie. [CGM].
        """
        state_number = Table(obs[0])
        self.total_score += SCORE_ARR[state_number]
    
    def __call__(self, n):
        """returns the score"""
        return self.total_score/(n*np.max(SCORE_ARR))


class Sum_of_Rewards():
    def __init__(self):
        self.sum_list = []
        self.running_sum = 0
    
    def reset(self):
        self.running_sum = 0
    
    def update(self, reward):
        self.running_sum += reward
    
    def end_episode(self):
        self.sum_list.append(self.running_sum)
        self.reset()
