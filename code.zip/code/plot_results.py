import numpy as np
import matplotlib.pyplot as plt
from config import EPISODE_LENGTH
from config import MEAL_PLAN
from config import PATIENT_NAME
from config import ACTION_SPACE_ARR
# MEAL_PLAN = [(1,63,.3), (2, 10), (4, 30)]

def plot_simulation_result(controller, patient, CGM=[], BG=[]):
    # parmaeters
    title = "{} controlled by {}".format(patient, controller)
    max_BG = 310
    # INSULIN_PLAN = [(0,0)]

    # Set names
    fig, ax = plt.subplots()
    ax.set_title(title, fontsize=17)
    ax.set_ylabel("BG measurements (mg/dl)", fontsize=14)
    ax.set_xlabel("Time (min)", fontsize=14)

    # Set limits
    ax.set_xlim([0, int(EPISODE_LENGTH*3)])
    ax.set_ylim([0, max_BG])

    # plot reward zone patches
    ax.axhspan(180, max_BG, alpha=0.2, color='red', lw=0)
    ax.axhspan(150, 180, alpha=0.3, color='green', lw=0)
    ax.axhspan(120, 150, alpha=0.4, color='green', lw=0)
    ax.axhspan(102, 120, alpha=0.5, color='green', lw=0)
    ax.axhspan(90, 102, alpha=0.4, color='green', lw=0)
    ax.axhspan(78, 90, alpha=0.3, color='green', lw=0)
    ax.axhspan(66, 78, alpha=0.2, color='green', lw=0)
    ax.axhspan(54, 66, alpha=0.3, color='red', lw=0)
    ax.axhspan(10, 54, alpha=0.4, color='red', lw=0)
    ax.axhspan(0, 10, alpha=0.6, color='red', lw=0)

    # plot TIR lines
    ax.axhline(70, color="yellow")
    ax.axhline(180, color="yellow", label="TIR limits")

    # plot CHO times and amount
    print_label = True
    for meal in MEAL_PLAN:
        if print_label:
            label = "Meals"
        else:
            label = ""
        meal_time = meal[0]*60
        meal_amount = "{}g CHO".format(meal[1])
        ax.axvline(x=meal_time, ymin=0, ymax=50/250, color="white", linestyle="dashed", label=label)
        ax.text(x=meal_time+7, y=4.5, s=meal_amount, color="white", rotation=90, fontsize=12)
        print_label = False

    # # plot inulin injection times and amount
    # for injection in INSULIN_PLAN:
    #     injection_time = injection[0]*60
    #     injection_amount = "{}U Bolus insulin".format(injection[1])
    #     ax.axvline(x=injection_time, ymin=0, ymax=50/250, color="white", linestyle="dashed")
    #     ax.text(x=injection_time+2, y=3, s=injection_amount, color="white", rotation=90)

    # Plot BG curvs:
    x_CGM = np.arange(len(CGM))*3
    x_BG = np.arange(len(BG))*3
    # xRL_CGM = np.arange(len(RL_CGM))*3
    # xRL_BG = np.arange(len(RL_BG))*3
    # xPID_CGM = np.arange(len(PID_CGM))*3
    # xPID_BG = np.arange(len(PID_BG))*3
    # xBB_CGM = np.arange(len(BB_CGM))*3
    # xBB_BG = np.arange(len(BB_BG))*3


    ax.plot(x_CGM, CGM, color="black", linestyle="solid", label="{} (CGM)".format(controller))
    ax.plot(x_BG, BG, color="blue", linestyle="solid", label="{} (BG)".format(controller))
    # ax.plot(xRL_CGM, RL_CGM, color="black", linestyle="solid", label="RL (CGM)")
    # ax.plot(xRL_BG, RL_BG, color="blue", linestyle="solid", label="RL (BG)")
    # ax.plot(xPID_CGM, PID_CGM, color="black", linestyle="dashed", label="PID (CGM)")
    # ax.plot(xPID_BG, PID_BG, color="blue", linestyle="dashed", label="PID (BG)")
    # ax.plot(xBB_CGM, BB_CGM, color="black", linestyle="dotted", label="BB (CGM)")
    # ax.plot(xBB_BG, BB_BG, color="black", linestyle="dotted", label="BB (BG)")
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    ax.legend(loc="upper right", fontsize=12, facecolor="gray")
    fig.tight_layout()
    fig.show()


def plot_insulin_dose(patient, RL=[], PID=[]):
    # parmaeters
    title = "{} Insulin schedule".format(patient)
    # max_BG = max(max(RL), max(PID), max(BB))
    

    # Set names
    fig, ax = plt.subplots()
    ax.set_title(title, fontsize=17)
    ax.set_ylabel("Bolus Insulin (U)", fontsize=14)
    ax.set_xlabel("Time (min)",fontsize=14)

    # Set limits
    # ax.set_xlim([0, int(EPISODE_LENGTH*3)])
    # ax.set_ylim([0, max_BG])

    # Plot Insulin schedule:
    xRL = np.arange(len(RL))*3
    xPID = np.arange(len(PID))*3

    ax.plot(xRL, RL, color="red", linestyle="solid", label="RL", alpha=0.6)
    ax.plot(xPID, PID, color="blue", linestyle="solid", label="PID", alpha=0.6)
    ax.legend(loc="upper right", fontsize=12)
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    fig.tight_layout()
    fig.show()



def plot_mean_sum_of_rewards(sum_of_rewards):
    title = "Mean sum of rewards during training"
    fig, ax = plt.subplots()
    ax.set_title(title, fontsize=17)
    ax.set_ylabel("Mean sum of reward", fontsize=14)
    ax.set_xlabel("Episode", fontsize=14)
    x = np.arange(len(sum_of_rewards))
    ax.plot(x, sum_of_rewards, linewidth=1)
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=12)
    fig.tight_layout()
    fig.show()
