from simglucose.controller.base import Controller
from simglucose.controller.base import Action
import logging

logger = logging.getLogger(__name__)


class PIDController(Controller):
    def __init__(self, P=1, I=0, D=0, target=140):
        self.P = P
        self.I = I
        self.D = D
        self.target = target
        self.integrated_state = 0
        self.prev_state = 0

    def policy(self, observation, reward, done, **kwargs):
        sample_time = kwargs.get('sample_time')

        # BG is the only state for this PID controller
        bg = observation
        control_input = self.P * (bg - self.target) + \
            self.I * self.integrated_state + \
            self.D * (bg - self.prev_state) / sample_time
        control_input = max(0, control_input)
        # print("-----------------------------------------------")
        # print("BG {}".format(bg))
        # print("P ==>{} x {} = {}".format(self.P, bg - self.target, self.P*(bg - self.target)))
        # print("I ==>{} x {} = {}".format(self.I, self.integrated_state, self.I*self.integrated_state))
        # print("D ==>{} x {} = {}".format(self.D, (bg-self.prev_state)/sample_time, self.D*(bg-self.prev_state)/sample_time))
        # print("action =", control_input)
        
        logger.info('Control input: {}'.format(control_input))

        # update the states
        self.prev_state = bg
        self.integrated_state += (bg - self.target) * sample_time
        logger.info('prev state: {}'.format(self.prev_state))
        logger.info('integrated state: {}'.format(self.integrated_state))

        # return the action
        action = Action(basal=0, bolus=control_input)
        return action

    def reset(self):
        self.integrated_state = 0
        self.prev_state = 0
