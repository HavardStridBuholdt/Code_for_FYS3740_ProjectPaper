#%% --------------------------------------------- Importing Packages --------------------------------------------
# Essentials packages
import numpy as np
import gymnasium as gym
from gymnasium.envs.registration import register
from datetime import datetime
import matplotlib.pyplot as plt
import pprint
from collections import defaultdict


# Simglucose objects
from simglucose.simulation.user_interface import simulate
from simglucose.controller.base import Controller, Action
from simglucose.simulation.scenario import CustomScenario
from simglucose.sensor.cgm import CGMSensor
from simglucose.actuator.pump import InsulinPump


# Modified Simglucose objects
import sys  # To be able to import the modified objects
sys.path.insert(0, "C:/Users/hsb19/OneDrive/Dokumenter/UiT/Semester/H2023/FYS-3740/RL/Tabular Solution Methods/code/simglucose_my_version/")
from simglucose_my_version.myt1dpatient import T1DPatient
from simglucose_my_version.mysimglucose_gym_env import T1DSimEnv
from simglucose_my_version.mysimglucose_gym_env import T1DSimGymnaisumEnv
import objects
import config as c






#%% ---------------------------------------------- Making RL Agant ----------------------------------------------

agent = objects.make_BGAgent(
    learning_rate=c.LEARNING_RATE,
    initial_epsilon=c.START_EPSILON, 
    epsilon_decay=c.EPSILON_DECAY, 
    final_epsilon=c.FINAL_EPSILON,
    discount_factor=c.DISCOUNT_FACTOR,
    initial_Q=c.INIT_Q,
    initial_N=c.INIT_N)

state = objects.new_State()
tir = objects.TIR()
score = objects.Score()
sum_of_rewards = objects.Sum_of_Rewards()






#%% ---------------------------------------------- Make Environment ---------------------------------------------
# Making scenarios
scenario = CustomScenario(start_time=c.START_TIME, scenario=c.MEAL_PLAN)

register(
    id='simglucose/adult2-v0_test',
    entry_point='mysimglucose_gym_env:T1DSimGymnaisumEnv',
    max_episode_steps=c.EPISODE_LENGTH,
    kwargs={'patient_name': c.PATIENT_NAME,
            "reward_fun": objects.reward_fun,
            'custom_scenario': scenario,
            'init_bg': c.INITIAL_BG,
            'seed': c.SEED}
)

env = gym.make('simglucose/adult2-v0_test', render_mode='human')



#%% ----------------------------------------------- Run simulation ----------------------------------------------
backup_frequency = c.BACKUP_FREQUENCY
episode_length_list = []

# Episode loop
print("Start training for {} episodes of training for {}".format(c.N_EPISODES, c.PATIENT_NAME))
startTime = datetime.now()
done = False
first_obs = 0
first_state = None
for episode in range(c.N_EPISODES):
    
    # Reset environment and states objects per episode
    observation, info = env.reset()
    state.reset()
    s = state.update(observation, 0, 0)
    tir.reset()
    score.reset()
    
    # Save first state:
    if episode == 0:
        first_obs = observation
        first_state = s
    
    # Simulation loop
    done = False
    t = 0
    while not done:
        
        # Choose action each hour
        if info['time'].minute == 0:
            action, insulin = agent.policy(s, c=c.C)
        else:
            insulin = 0
        
        # Compute next action and reward
        next_observation, reward, terminated, truncated, info = env.step(insulin)
        
        # Update comparison criteria
        tir.update(observation)
        score.update(next_observation)
        
        # Update state each hour or if terminated
        if info["time"].minute == 0 and info["time"].hour > c.START_TIME.hour or terminated:
            next_s = state.update(next_observation, action, t+1)
            agent.update(s, action, reward, terminated, next_s)
            sum_of_rewards.update(reward)
            s = next_s
        
        # # Print info per timestep t:
        # print("-------------------------------------------------------------------------------------------")
        # print("episode", episode)
        # print("step", t)                       # Timestep      {0, 100}
        # print("observation", observation[0])   # Next state    {BG level at time t}
        # print("state", s)
        # print("action", action)
        # print("insulin value", insulin)
        # # print("PID output", controller.policy(observation, reward, done, sample_time=info['sample_time']))
        # print("next observation", next_observation[0])
        # print("next state", next_s)
        # print("reward", reward)             # Reward        {-10, 1}
        # print("terminated", terminated)     # Reached the terminate stat or not?    {True / False}
        # print("truncated", truncated)       # Ran out of timesteps or not?          {True / False}
        # print("info", info)                 # Additional info   {sample time, patient name, meal, patient state, time, bg, lbgi, hbgi, risk}
        
        # # Render episode
        # if episode in c.SAVE_INTERVALS:
        #     env.render()
        
        # End of episode
        if terminated or truncated:
            episode_length_list.append(t+1)
            print("Episode {} out of {} finished after {} timesteps".format(episode, c.N_EPISODES, t + 1))
            print('Score:   {}'.format(score(c.EPISODE_LENGTH)))
            print('TIR:     {}'.format(tir(c.EPISODE_LENGTH)))
            # if episode in c.SAVE_INTERVALS:
                # plt.savefig("results/figures/episode{}.png".format(t))
                # np.save("results/info/episode{}".format(t), [episode, t, score(c.EPISODE_LENGTH), tir(c.EPISODE_LENGTH)], allow_pickle=True)
            # plt.close()
            done = True
        
        
        t += 1
        observation = next_observation
    sum_of_rewards.end_episode()
    agent.update_epsilon()
    
    # Save a backup of Q and N files
    if episode >= backup_frequency:
        np.save("results/{}/RL/backups/Q{}".format(c.PATIENT_NAME, episode), dict(agent.Q), allow_pickle=True)
        np.save("results/{}/RL/backups/N{}".format(c.PATIENT_NAME, episode), dict(agent.N), allow_pickle=True)
        backup_frequency += c.BACKUP_FREQUENCY
    print("==================================================")
print("{} Episodes took {}".format(episode+1, datetime.now()-startTime))



# Save results
np.save("results/{}/RL/Q_file".format(c.PATIENT_NAME), dict(agent.Q), allow_pickle=True)
np.save("results/{}/RL/Training_error_file".format(c.PATIENT_NAME), agent.training_error, allow_pickle=True)
np.save("results/{}/RL/sum_of_rewards".format(c.PATIENT_NAME), sum_of_rewards.sum_list, allow_pickle=True)
np.save("results/{}/RL/Episode_length".format(c.PATIENT_NAME), episode_length_list, allow_pickle=True)
np.save("results/{}/RL/N_file".format(c.PATIENT_NAME), dict(agent.N), allow_pickle=True)



# Plot sum of rewards an episode length
plt.subplot(211)
plt.plot(sum_of_rewards.sum_list)
plt.xlabel("Episodes")
plt.ylabel("Sum of rewards during episode")

plt.subplot(212)
plt.plot(episode_length_list)
plt.xlabel("Episodes")
plt.ylabel("Episode length")

plt.show()
plt.savefig("results/{}/RL/evaluation_plot.png".format(c.PATIENT_NAME))
plt.close()

