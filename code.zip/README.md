This repository includes the code and data used in the FYS-3740 Project paper



The title of the accompanying paper is:
Comparing Reinforcement Learning And Traditional Methods For Blood Glucose Control In In-Silico Type-1 Diabetes Patients.



The directory /simglucose_my_version contains modified version of files from Jinyu Xie’s simglucose simulator
found at https://github.com/jxx123/simglucose.

