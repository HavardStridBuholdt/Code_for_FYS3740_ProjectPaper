import numpy as np
from datetime import datetime

# ----------------------------------------------- Simulation setup ----------------------------------------------
# Scenario parameters
START_HOUR = 4
START_TIME = datetime(2018, 1, 1, START_HOUR, 0)
EPISODE_LENGTH = int(20*60/3)
MEAL_PLAN = [(7-START_HOUR, 65), (12-START_HOUR, 59), (17-START_HOUR, 57), (20-START_HOUR, 19)]
# Prev Scenario:  MEAL_PLAN      = [(1, 63.3)]      # (hours after start time, CHO dosage)
#                 EPISODE_LENGTH = int(6*60/3)


# Patient parameters
PATIENT_NAME = 'adult#004'
INITIAL_BG = 180
SEED = 1




# --------------------------------------------------- RL agent --------------------------------------------------
# Hyperparameters
N_EPISODES = 1000
LEARNING_RATE = 0.3
START_EPSILON = 0.1 # 1.0
EPSILON_DECAY = 0 # START_EPSILON / (N_EPISODES/2)
FINAL_EPSILON = 0.1
DISCOUNT_FACTOR = 1
C = 0


# Initialize agent:
# INIT_Q = np.array({})
# INIT_N = np.array({}) 
PREVIOUS_BATCH_FOLDER = "episode_1000_to_2000"
INIT_Q = np.load("results/{}/RL/{}/Q_file.npy".format(PATIENT_NAME, PREVIOUS_BATCH_FOLDER), allow_pickle=True)
INIT_N = np.load("results/{}/RL/{}/N_file.npy".format(PATIENT_NAME, PREVIOUS_BATCH_FOLDER), allow_pickle=True)


# State, Action, and reward setup:
BG_THRESHOLDS = np.array([54, 66, 78, 90, 102, 120, 150, 180]) 
REWARD_ARR = np.array([-10, -7.5, 0, 1/3, 2/3, 1, 2/3, 1/3, -5])
SCORE_ARR = np.array([0, 5/22, 10/11, 31/33, 32/33, 1, 32/33, 31/33, 5/11])
ACTION_SPACE_ARR = np.array([0, 0.5, 1, 1.5, 2])   # np.array([0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5])
TIR_THRESHOLDS = (70, 180)
STATE_LENGTH = 6                # Used to spesify the length of the state S = [ STATE_LENGTH "BG vlues" + t]
N_PAST_INSULIN_INJECTIONS = 3   # Used to spesify the number of past insulin values to be added in the state
N_PAST_BG_VALUES = 4            # Used to spesify the number of BG values added in the state




# ----------------------------------- Backup and check results during training ----------------------------------
SAVE_INTERVALS =  [0, 200, 400, 600, 800, 999]
CHECK_INTERVALS = np.arange(0, N_EPISODES, 200).astype(np.int64)
BACKUP_FREQUENCY = 200




# -------------------------------------------------- Validation -------------------------------------------------
# Simulation 
N_VAL_EPISODES = 1
CONTROLLER = "RL"
Q_PATH = "results/{}/RL/episode_2000_to_3000/Q_file.npy".format(PATIENT_NAME)

# PID controller:
P, I, D = 0.017777777777777778, 0.00011111111111111112, 2.0
BG_TARGET = 111
SAMPLE_TIME = 60

# Grid search parameters
SEARCH = False
P_INTERVAL = 0
I_INTERVAL = 4e-7
D_INTERVAL = 0
