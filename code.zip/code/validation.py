# %% Import
# Essentials packages
import numpy as np
import gymnasium as gym
from gymnasium.envs.registration import register
from datetime import datetime
import matplotlib.pyplot as plt
import pprint
from collections import defaultdict


# Simglucose objects
from simglucose.simulation.user_interface import simulate
from simglucose.controller.base import Controller, Action
from simglucose.simulation.scenario import CustomScenario
from simglucose.sensor.cgm import CGMSensor
from simglucose.actuator.pump import InsulinPump
from simglucose.controller.basal_bolus_ctrller import BBController


# Modified Simglucose objects
import sys  # To be able to import the modified objects
sys.path.insert(0, "C:/Users/hsb19/OneDrive/Dokumenter/UiT/Semester/H2023/FYS-3740/RL/Tabular Solution Methods/code/simglucose_my_version/")
from simglucose_my_version.myt1dpatient import T1DPatient
from simglucose_my_version.mysimglucose_gym_env import T1DSimEnv
from simglucose_my_version.mysimglucose_gym_env import T1DSimGymnaisumEnv
from simglucose_my_version.myPIDController import PIDController
import objects
import config as c
from plot_results import plot_simulation_result
from plot_results import plot_insulin_dose


#%% RLController and Controller_state()
class RLController():
    def __init__(self, Q_path):
        load_dict = np.load(Q_path, allow_pickle=True)
        Q = defaultdict(lambda: np.zeros(len(c.ACTION_SPACE_ARR)).astype(np.float64))
        Q.update(load_dict.item())
        self.Q = Q
    
    def policy(self, obs, reward, done, sample_time):
        action = np.argmax(self.Q[obs])
        return action, c.ACTION_SPACE_ARR[action]
    
    def reset(self):
        pass


class Controller_State():
    def __init__(self):
        pass
    def reset(self):
        pass
    def update(self, obs, action, t):
        return obs[0]



#%% Choose Controller and Make criteria objects


# Make Controller and State objects
if c.CONTROLLER == "RL":
    controller = RLController(Q_path=c.Q_PATH)
    state = objects.new_State()
    print("RL Controller chosen")


if c.CONTROLLER == "PID":
    controller = PIDController(P=c.P, I=c.I, D=c.D, target=c.BG_TARGET)
    state = Controller_State()
    print("PID Controller chosen. P={}, I={}, D={}".format(c.P, c.I, c.D))


if c.CONTROLLER == "BB":
    controller = BBController()
    state = Controller_State()
    print("BB Controller chosen")



# Make criteria objects:
tir = objects.TIR()
score = objects.Score()
sum_of_rewards = objects.Sum_of_Rewards()



#%% simulation environment

scenario = CustomScenario(start_time=c.START_TIME, scenario=c.MEAL_PLAN)

register(
    id='simglucose/adult2-v0_test',
    entry_point='mysimglucose_gym_env:T1DSimGymnaisumEnv',
    max_episode_steps=c.EPISODE_LENGTH,
    kwargs={'patient_name': c.PATIENT_NAME,
            "reward_fun": objects.reward_fun,
            'custom_scenario': scenario,
            'init_bg': c.INITIAL_BG,
            'seed': c.SEED}
)

env = gym.make('simglucose/adult2-v0_test', render_mode='human')

# # Test env
# print(env)
# obs, info = env.reset()
# print(obs)
# print(info)
# print(crash)


#%% Grid search for PID hyperparameters

if c.SEARCH:
    # Construct search intervals:                                           # Initial PID values:
    p_search_interval = np.linspace(c.P-c.P_INTERVAL, c.P+c.P_INTERVAL, 1) # 0.1
    i_search_interval = np.linspace(c.I-c.I_INTERVAL, c.I+c.I_INTERVAL, 10) # 0.001
    d_search_interval = np.linspace(c.D-c.D_INTERVAL, c.D+c.D_INTERVAL, 1) # 1
    
    # Combine all combinations of P,I and D values.
    combinations = []
    for p in p_search_interval:
        for i in i_search_interval:
            for d in d_search_interval:
                combinations.append((p, i, d))

    search_arr = np.zeros((len(combinations), 3))
    for i in range(len(combinations)):
        search_arr[i,:] = combinations[i]
    
    # Overwrite the Controller and the number of episodes
    c.N_VAL_EPISODES = len(combinations)
    print("Now conducting a {} episodes long grid search for PID gains".format(c.N_VAL_EPISODES))




#%% Run validation simulation

# Comparison data
tir_list = []
score_list = []


# Episode Loop:
done = False
first_obs = 0
first_state = None
for episode in range(c.N_VAL_EPISODES):
    
    if c.SEARCH:
        # Change and print PID gains
        P,I,D = search_arr[episode,:]
        controller.__init__(P=P, I=I, D=D, target=c.BG_TARGET)
        print("P={}, I={}, D={}".format(P,I,D))
    
    # Result data
    obs_list = []
    BG_list = []
    insulin_list = []
    
    # Reset environment and states objects per episode
    observation, info = env.reset()
    controller.reset()
    state.reset()
    s = state.update(observation, 0, 0)
    tir.reset()
    score.reset()
    
    # Save first state:
    if episode == 0:
        first_obs = observation
        first_state = s
    
    
    
    # Simulation Loop
    done = False
    reward = c.REWARD_ARR[objects.Table(int(observation[0]))]
    t = 0
    while not done:
        
        # Choose action
        if info['time'].minute == 0:
            action, insulin = controller.policy(s, reward, done, sample_time=c.SAMPLE_TIME)
        else:
            insulin = 0
        
        # Save CGM, BG and actions
        obs_list.append(observation[0])
        BG_list.append(info["bg"])      # Subcutaneus BG levels, (ie. BG in interstitial fluid not in the blood and therby no delay only noise)
        insulin_list.append(insulin)
        
        # Compute next action and reward
        next_observation, reward, terminated, truncated, info = env.step(insulin)
        
        # Update comparison criteria
        tir.update(observation)
        score.update(next_observation)
        
        # Update state
        if info["time"].minute == 0 and info["time"].hour > c.START_TIME.hour or terminated:
            next_s = state.update(next_observation, action, t+1)
            sum_of_rewards.update(reward)
            s = next_s
        
        # # Print info per timestep t:
        # print("-------------------------------------------------------------------------------------------")
        # print("episode", episode)
        # print("step", t)                       # Timestep      {0, 100}
        # print("observation", observation[0])   # Next state    {BG level at time t}
        # print("state", s)
        # print("action", action)
        # print("insulin value", insulin)
        # # print("PID output", controller.policy(observation, reward, done, sample_time=info['sample_time']))
        # print("next observation", next_observation[0])
        # print("next state", next_s)
        # print("reward", reward)             # Reward        {-10, 1}
        # print("terminated", terminated)     # Reached the terminate stat or not?    {True / False}
        # print("truncated", truncated)       # Ran out of timesteps or not?          {True / False}
        # print("info", info)                 # Additional info   {sample time, patient name, meal, patient state, time, bg, lbgi, hbgi, risk}
        
        # # Render episode:
        # env.render()
        
        # End of episode:
        if terminated or truncated:
            episode_score = np.copy(score(c.EPISODE_LENGTH))
            episode_tir = np.copy(tir(c.EPISODE_LENGTH))
            print("Episode {} finished after {} timesteps".format(episode, t + 1))
            print('Score:   {}'.format(episode_score))
            print('TIR:     {}'.format(episode_tir))
            score_list.append(episode_score)
            tir_list.append(episode_tir)
            # env.close()
            done = True
        
        t += 1
        observation = next_observation
    sum_of_rewards.end_episode()
    t += 1
    print("==================================================")

#%% Saving / printing result



# Saving result data:
if not c.SEARCH:
    np.save("results/{}/{}/CGM_curv".format(c.PATIENT_NAME, c.CONTROLLER), obs_list, allow_pickle=True)
    np.save("results/{}/{}/BG_curv".format(c.PATIENT_NAME, c.CONTROLLER), BG_list, allow_pickle=True)
    np.save("results/{}/{}/insulin_schedule".format(c.PATIENT_NAME, c.CONTROLLER), insulin_list, allow_pickle=True)
    
    plot_simulation_result(controller=c.CONTROLLER, patient=c.PATIENT_NAME, CGM=obs_list, BG=BG_list)
    plt.show()



# Printing and saving best PID gains
if c.SEARCH:
    score_arr = np.array(score_list)
    best_combination = np.argmax(score_arr)
    best_P, best_I, best_D = search_arr[best_combination,:]
    print("The best score {} was reached in Episode {}, with P={}, I={} and D={}".format(np.max(score_arr),
                                                                                        best_combination,
                                                                                        best_P,
                                                                                        best_I,
                                                                                        best_D))
    np.save("results/{}/PID/optimal_gain".format(c.PATIENT_NAME), np.array([best_P, best_I, best_D]), allow_pickle=True)



# Ploting comperison criteria's per episode
if c.N_VAL_EPISODES > 1:
    fig, ax = plt.subplots(2)
    
    ax[0].set_ylabel("TIR")
    ax[0].set_xlabel("Episode")
    ax[1].set_ylabel("Score")
    ax[1].set_xlabel("Episode")
    
    ax[0].set_ylim([-0.1, 1.1])
    ax[1].set_ylim([-0.1, 1.1])
    
    ax[0].plot(tir_list, color="black")
    ax[1].plot(score_list, color="black")
    
    plt.show()
    plt.savefig("results/{}/{}/validation_criteria_plot.png".format(c.PATIENT_NAME, c.CONTROLLER))
    plt.close()


