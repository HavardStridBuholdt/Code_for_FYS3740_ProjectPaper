import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt 
import config as c
from plot_results import plot_insulin_dose
from plot_results import plot_simulation_result
from plot_results import plot_mean_sum_of_rewards


# # # ----------------------------------------------- Plot result -----------------------------------------------
patient = "adult#004"
RL_batch_folder = "episode_2000_to_3000"
PID_batch_folder = "v3"

rl_bg = np.load("results/{}/RL/{}/BG_curv.npy".format(patient, RL_batch_folder), allow_pickle=True)
rl_cgm = np.load("results/{}/RL/{}/CGM_curv.npy".format(patient, RL_batch_folder), allow_pickle=True)
pid_bg = np.load("results/{}/PID/{}/BG_curv.npy".format(patient,PID_batch_folder), allow_pickle=True)
pid_cgm = np.load("results/{}/PID/{}/CGM_curv.npy".format(patient, PID_batch_folder), allow_pickle=True)


rl_dose = np.load("results/{}/RL/{}/insulin_schedule.npy".format(patient, RL_batch_folder), allow_pickle=True)
pid_dose = np.load("results/{}/PID/{}/insulin_schedule.npy".format(patient, PID_batch_folder), allow_pickle=True)

plot_simulation_result(controller="RL", patient=patient, CGM=rl_cgm, BG=rl_bg)
plot_simulation_result(controller="PID", patient=patient, CGM=pid_cgm, BG=pid_bg)
plot_insulin_dose(patient=patient, RL=rl_dose, PID=pid_dose)
plt.show()









# # ----------------------------------------------- Test bug -----------------------------------------------
# patient = "adult#002"

# sum_of_rewards = np.load("results/{}/RL/episode_0_to_1000/sum_of_rewards.npy".format(patient), allow_pickle=True)
# episode_length = np.load("results/{}/RL/episode_0_to_1000/Episode_length.npy".format(patient), allow_pickle=True)

# plt.subplot(211)
# plt.plot(sum_of_rewards)
# plt.title(patient)
# plt.xlabel("Episodes")
# plt.ylabel("Sum of rewards during episode")

# plt.subplot(212)
# plt.plot(episode_length)
# plt.xlabel("Episodes")
# plt.ylabel("Episode length")

# plt.show()








# # ----------------------------------------------- Test stuff -----------------------------------------------

batches = ["episode_0_to_1000", "episode_1000_to_2000", "episode_2000_to_3000"]
patients = ["adult#001", "adult#002", "adult#003", "adult#004"]

mean_sum_list = np.zeros(len(batches)*1000).astype(np.float64)
start, stop = 0,1000
for batch in batches:
    batch_mean = np.zeros(1000).astype(np.float64)
    for patient in patients:
        sum_of_reward = np.load("results/{}/RL/{}/sum_of_rewards.npy".format(patient, batch), allow_pickle=True)
        batch_mean = batch_mean + sum_of_reward
    mean_sum_list[start:stop] = batch_mean/len(batches)
    start += 1000
    stop += 1000

plot_mean_sum_of_rewards(mean_sum_list)
plt.show()
